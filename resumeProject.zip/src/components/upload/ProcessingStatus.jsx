
import React from 'react';
import { Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ProcessingStatus = ({ isProcessing, processedCount, totalFiles, onProcess }) => {
  return (
    <div className="flex justify-between items-center mt-6">
      <div>
        {isProcessing && (
          <div className="flex items-center gap-2 text-blue-600">
            <div className="animate-spin">
              <Upload className="w-5 h-5" />
            </div>
            <span>
              Processing {processedCount}/{totalFiles} files...
            </span>
          </div>
        )}
      </div>

      <Button
        onClick={onProcess}
        disabled={isProcessing || totalFiles === 0}
        className="bg-blue-600 hover:bg-blue-700"
      >
        {isProcessing ? 'Processing...' : 'Process Resumes'}
      </Button>
    </div>
  );
};

export default ProcessingStatus;
