
import React from 'react';
import { motion } from 'framer-motion';
import { FileText, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const FileList = ({ files, onRemoveFile, isProcessing }) => {
  if (files.length === 0) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-white rounded-xl p-8 shadow-md border border-gray-200"
    >
      <h2 className="text-xl font-semibold mb-4">Selected Files ({files.length})</h2>

      <div className="space-y-3 max-h-64 overflow-y-auto mb-6">
        {files.map((file, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center gap-3 overflow-hidden">
              <FileText className="w-5 h-5 text-blue-500 flex-shrink-0" />
              <div className="overflow-hidden">
                <p className="font-medium truncate" title={file.name}>{file.name}</p>
                <p className="text-sm text-gray-500">
                  {(file.size / 1024).toFixed(2)} KB
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onRemoveFile(index)}
              disabled={isProcessing}
              className="text-red-500 hover:text-red-700 hover:bg-red-50 flex-shrink-0 ml-2"
            >
              <X className="w-4 h-4" />
            </Button>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default FileList;
