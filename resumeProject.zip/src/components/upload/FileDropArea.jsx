
import React from 'react';
import { motion } from 'framer-motion';
import { Upload } from 'lucide-react';

const FileDropArea = ({ isDragging, onDragOver, onDragLeave, onDrop, onClick }) => {
  return (
    <div
      className={`file-drop-area p-8 rounded-lg text-center cursor-pointer ${
        isDragging ? 'active' : ''
      }`}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
      onClick={onClick}
    >
      <motion.div
        initial={{ scale: 0.9 }}
        animate={{ scale: isDragging ? 1.1 : 1 }}
        transition={{ duration: 0.2 }}
      >
        <Upload className="w-16 h-16 mx-auto mb-4 text-blue-500" />
        <h3 className="text-lg font-semibold mb-2">Drag & Drop Resumes Here</h3>
        <p className="text-gray-500 mb-4">
          or click to browse your files
        </p>
        <p className="text-sm text-gray-400">
          Supports PDF, TXT, DOC, DOCX files
        </p>
      </motion.div>
    </div>
  );
};

export default FileDropArea;
