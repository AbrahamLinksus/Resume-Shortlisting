
import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

const ItemList = ({ items, onRemoveItem, itemClassName }) => {
  if (items.length === 0) {
    return <p className="text-sm text-gray-500 italic">No items added yet</p>;
  }

  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`flex items-center gap-1 px-3 py-1 rounded-full ${itemClassName}`}
        >
          <span>{item}</span>
          <button
            onClick={() => onRemoveItem(index)}
            className="ml-1 opacity-70 hover:opacity-100"
          >
            <X className="w-3 h-3" />
          </button>
        </motion.div>
      ))}
    </div>
  );
};

export default ItemList;
