
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import ItemList from './ItemList';

const CriteriaSection = ({ title, category, criteria, onWeightChange, children }) => {
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <h2 className="text-lg font-semibold">{title}</h2>
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <span className="text-sm text-gray-500">Importance:</span>
          <div className="w-32">
            <Slider
              value={[criteria.weight]}
              min={0}
              max={10}
              step={1}
              onValueChange={(value) => onWeightChange(category, value)}
              className="criteria-slider"
              disabled={criteria.weight === undefined}
            />
          </div>
          <span className="text-sm font-medium w-8 text-right">
            {criteria.weight !== undefined ? `${criteria.weight}/10` : '-'}
          </span>
        </div>
      </div>
      {children}
    </div>
  );
};

export const SkillsCriteria = ({ criteria, onWeightChange, localCriteria, setLocalCriteria, newSkill, setNewSkill }) => {
  const addSkill = () => {
    if (newSkill.trim() === '') return;
    setLocalCriteria(prev => ({
      ...prev,
      skills: { ...prev.skills, items: [...prev.skills.items, newSkill.trim()] }
    }));
    setNewSkill('');
  };

  const removeSkill = (index) => {
    setLocalCriteria(prev => ({
      ...prev,
      skills: { ...prev.skills, items: prev.skills.items.filter((_, i) => i !== index) }
    }));
  };

  return (
    <CriteriaSection title="Required Skills" category="skills" criteria={criteria} onWeightChange={onWeightChange}>
      <div className="flex gap-2">
        <Input
          value={newSkill}
          onChange={(e) => setNewSkill(e.target.value)}
          placeholder="Add a required skill..."
          className="flex-1"
          onKeyDown={(e) => e.key === 'Enter' && addSkill()}
        />
        <Button onClick={addSkill} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4" />
        </Button>
      </div>
      <ItemList
        items={localCriteria.skills.items}
        onRemoveItem={removeSkill}
        itemClassName="bg-blue-100 text-blue-800"
      />
    </CriteriaSection>
  );
};

export const ExperienceCriteria = ({ criteria, onWeightChange, localCriteria, setLocalCriteria }) => {
  const handleExperienceYearsChange = (years) => {
    setLocalCriteria(prev => ({
      ...prev,
      experience: { ...prev.experience, years: Math.max(0, parseInt(years) || 0) }
    }));
  };

  return (
    <CriteriaSection title="Minimum Experience" category="experience" criteria={criteria} onWeightChange={onWeightChange}>
      <div className="flex items-center gap-4">
        <Label htmlFor="experience-years" className="min-w-[120px]">
          Years of Experience:
        </Label>
        <Input
          id="experience-years"
          type="number"
          min="0"
          max="50"
          value={localCriteria.experience.years}
          onChange={(e) => handleExperienceYearsChange(e.target.value)}
          className="w-24"
        />
      </div>
    </CriteriaSection>
  );
};

export const EducationCriteria = ({ criteria, onWeightChange, localCriteria, setLocalCriteria }) => {
  const handleEducationLevelChange = (level) => {
    setLocalCriteria(prev => ({
      ...prev,
      education: { ...prev.education, level }
    }));
  };

  return (
    <CriteriaSection title="Education Level" category="education" criteria={criteria} onWeightChange={onWeightChange}>
      <div className="flex items-center gap-4">
        <Label htmlFor="education-level" className="min-w-[120px]">
          Minimum Level:
        </Label>
        <Select
          value={localCriteria.education.level}
          onValueChange={handleEducationLevelChange}
        >
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Select education level" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="high_school">High School</SelectItem>
            <SelectItem value="associate">Associate's Degree</SelectItem>
            <SelectItem value="bachelor">Bachelor's Degree</SelectItem>
            <SelectItem value="master">Master's Degree</SelectItem>
            <SelectItem value="phd">PhD / Doctorate</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </CriteriaSection>
  );
};

export const KeywordsCriteria = ({ criteria, onWeightChange, localCriteria, setLocalCriteria, newKeyword, setNewKeyword }) => {
  const addKeyword = () => {
    if (newKeyword.trim() === '') return;
    setLocalCriteria(prev => ({
      ...prev,
      keywords: { ...prev.keywords, items: [...prev.keywords.items, newKeyword.trim()] }
    }));
    setNewKeyword('');
  };

  const removeKeyword = (index) => {
    setLocalCriteria(prev => ({
      ...prev,
      keywords: { ...prev.keywords, items: prev.keywords.items.filter((_, i) => i !== index) }
    }));
  };

  return (
    <CriteriaSection title="Additional Keywords" category="keywords" criteria={criteria} onWeightChange={onWeightChange}>
      <div className="flex gap-2">
        <Input
          value={newKeyword}
          onChange={(e) => setNewKeyword(e.target.value)}
          placeholder="Add a keyword to search for..."
          className="flex-1"
          onKeyDown={(e) => e.key === 'Enter' && addKeyword()}
        />
        <Button onClick={addKeyword} className="bg-purple-600 hover:bg-purple-700">
          <Plus className="w-4 h-4" />
        </Button>
      </div>
      <ItemList
        items={localCriteria.keywords.items}
        onRemoveItem={removeKeyword}
        itemClassName="bg-purple-100 text-purple-800"
      />
    </CriteriaSection>
  );
};
