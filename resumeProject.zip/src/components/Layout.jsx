
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FileText, Upload, SlidersHorizontal, List, BarChart3 } from 'lucide-react';

const Layout = ({ children }) => {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'Dashboard', icon: <BarChart3 className="w-5 h-5" /> },
    { path: '/upload', label: 'Upload Resumes', icon: <Upload className="w-5 h-5" /> },
    { path: '/criteria', label: 'Set Criteria', icon: <SlidersHorizontal className="w-5 h-5" /> },
    { path: '/results', label: 'View Results', icon: <List className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2">
            <FileText className="w-8 h-8" />
            <span className="text-xl font-bold">Resume Shortlister</span>
          </Link>
        </div>
      </header>

      <div className="flex flex-1">
        <nav className="w-64 bg-card shadow-md hidden md:block border-r border-border">
          <div className="p-4">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className={`relative flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                      location.pathname === item.path
                        ? 'bg-primary text-primary-foreground'
                        : 'text-foreground hover:bg-secondary'
                    }`}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                    {location.pathname === item.path && (
                      <motion.div
                        layoutId="nav-indicator"
                        className="absolute right-0 w-1 h-full bg-accent rounded-l-md"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.3 }}
                      />
                    )}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </nav>

        <main className="flex-1 p-6 bg-background">
          <div className="container mx-auto">
            {children}
          </div>
        </main>
      </div>

      <footer className="bg-card text-muted-foreground py-4 border-t border-border">
        <div className="container mx-auto px-4 text-center text-sm">
          <p>© {new Date().getFullYear()} Resume Shortlister. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
