
import React from 'react';
import { Award } from 'lucide-react';
import { getScoreColor, getScoreText } from '@/lib/scoreUtils';

const ScoreCard = ({ score }) => {
  const colorClass = getScoreColor(score).replace('bg-', '');

  return (
    <div className="bg-card rounded-xl p-6 shadow-md border border-border">
      <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-foreground">
        <Award className="w-5 h-5 text-primary" />
        Match Score
      </h2>

      <div className="flex flex-col items-center">
        <div className="relative w-32 h-32 mb-4">
          <svg className="w-full h-full" viewBox="0 0 36 36">
            <path
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="hsl(var(--muted))"
              strokeWidth="3"
            />
            <path
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke={`var(--${colorClass})`}
              strokeWidth="3"
              strokeDasharray={`${score}, 100`}
              strokeLinecap="round"
              transform="rotate(-90 18 18)"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-3xl font-bold text-foreground">{score}%</span>
          </div>
        </div>

        <p className="text-lg font-semibold text-center text-foreground">
          {getScoreText(score)}
        </p>
      </div>
    </div>
  );
};

export default ScoreCard;
