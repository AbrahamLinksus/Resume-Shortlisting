
import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Briefcase, GraduationCap, Code } from 'lucide-react';

const DetailSection = ({ icon, title, children }) => (
  <div>
    <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
      {icon}
      {title}
    </h2>
    <div className="text-gray-700">{children}</div>
  </div>
);

const ResumeContent = ({ resume }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="md:col-span-2 bg-white rounded-xl p-8 shadow-md border border-gray-200"
    >
      <div className="flex items-center gap-3 mb-6">
        <FileText className="w-6 h-6 text-blue-600" />
        <h1 className="text-2xl font-bold truncate" title={resume.fileName}>{resume.fileName}</h1>
      </div>

      <div className="space-y-6">
        <DetailSection icon={<Briefcase className="w-5 h-5 text-gray-500" />} title="Experience">
          <p>{resume.experience} years of professional experience</p>
        </DetailSection>

        <DetailSection icon={<GraduationCap className="w-5 h-5 text-gray-500" />} title="Education">
          <p className="capitalize">
            {resume.education ? resume.education.replace('_', ' ') : 'Not specified'}
          </p>
        </DetailSection>

        <DetailSection icon={<Code className="w-5 h-5 text-gray-500" />} title="Skills">
          {resume.skills.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {resume.skills.map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                >
                  {skill}
                </span>
              ))}
            </div>
          ) : (
            <p className="italic text-gray-500">No skills detected</p>
          )}
        </DetailSection>

        <DetailSection icon={<FileText className="w-5 h-5 text-gray-500" />} title="Resume Content">
          <div className="bg-gray-50 p-4 rounded-md max-h-96 overflow-y-auto border border-gray-200">
            <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans">
              {resume.fullText}
            </pre>
          </div>
        </DetailSection>
      </div>
    </motion.div>
  );
};

export default ResumeContent;
