
import React from 'react';

const ResumeInfoCard = ({ resume }) => {
  return (
    <div className="bg-card rounded-xl p-6 shadow-md border border-border">
      <h2 className="text-lg font-semibold mb-4 text-foreground">Resume Info</h2>
      <div className="space-y-3">
        <div className="flex justify-between">
          <span className="text-sm text-muted-foreground">Uploaded:</span>
          <span className="text-sm text-foreground">
            {new Date(resume.uploadDate).toLocaleDateString()}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm text-muted-foreground">File Name:</span>
          <span className="text-sm text-foreground truncate" title={resume.fileName}>{resume.fileName}</span>
        </div>
      </div>
    </div>
  );
};

export default ResumeInfoCard;
