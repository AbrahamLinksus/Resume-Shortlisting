
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ResumeHeader = ({ onDelete }) => {
  const navigate = useNavigate();

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
    >
      <Button
        variant="ghost"
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 self-start"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Results
      </Button>

      <Button
        variant="destructive"
        onClick={onDelete}
        className="flex items-center gap-2 self-end sm:self-center"
      >
        <Trash2 className="w-4 h-4" />
        Delete Resume
      </Button>
    </motion.div>
  );
};

export default ResumeHeader;
