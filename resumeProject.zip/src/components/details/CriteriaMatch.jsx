
import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

const CriteriaMatchItem = ({ label, required, actual, isMatched, weight }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <span className="text-sm font-medium">{label}</span>
      {weight !== undefined && <span className="text-xs text-gray-500">Weight: {weight}/10</span>}
    </div>
    <div className="flex items-center justify-between">
      <span className="text-xs text-gray-600">Required: {required}</span>
      <div className="flex items-center gap-1">
         <span className={`text-xs ${isMatched ? 'text-green-600' : 'text-red-500'}`}>
           {actual}
         </span>
         {isMatched ? <CheckCircle className="w-3 h-3 text-green-500" /> : <XCircle className="w-3 h-3 text-red-500" />}
      </div>
    </div>
  </div>
);

const CriteriaMatchList = ({ title, items, weight }) => (
  <div>
    <div className="flex justify-between mb-1">
      <span className="text-sm font-medium">{title}</span>
      {weight !== undefined && <span className="text-xs text-gray-500">Weight: {weight}/10</span>}
    </div>
    <div className="space-y-1">
      {items.map((item, index) => (
        <div key={index} className="flex items-center justify-between">
          <span className="text-sm">{item.name}</span>
          <div className="flex items-center gap-1">
            <span className={`text-xs ${item.matched ? 'text-green-600' : 'text-red-500'}`}>
              {item.matched ? 'Matched' : 'Not Found'}
            </span>
             {item.matched ? <CheckCircle className="w-3 h-3 text-green-500" /> : <XCircle className="w-3 h-3 text-red-500" />}
          </div>
        </div>
      ))}
    </div>
  </div>
);


const CriteriaMatch = ({ resume, criteria }) => {
  const educationLevels = { 'high_school': 1, 'associate': 2, 'bachelor': 3, 'master': 4, 'phd': 5 };
  const resumeEduLevel = educationLevels[resume.education] || 0;
  const criteriaEduLevel = educationLevels[criteria.education.level] || 0;

  const skillItems = criteria.skills.items.map(skill => ({
    name: skill,
    matched: resume.skills.some(s => s.toLowerCase().includes(skill.toLowerCase()))
  }));

  const keywordItems = criteria.keywords.items.map(keyword => ({
    name: keyword,
    matched: resume.fullText.toLowerCase().includes(keyword.toLowerCase())
  }));

  return (
    <div className="bg-white rounded-xl p-6 shadow-md border border-gray-200">
      <h2 className="text-lg font-semibold mb-4">Criteria Matching Breakdown</h2>
      <div className="space-y-4">
        {criteria.skills.items.length > 0 && (
          <CriteriaMatchList title="Skills" items={skillItems} weight={criteria.skills.weight} />
        )}
        {criteria.experience.years > 0 && (
          <CriteriaMatchItem
            label="Experience"
            required={`${criteria.experience.years} years`}
            actual={`${resume.experience} years`}
            isMatched={resume.experience >= criteria.experience.years}
            weight={criteria.experience.weight}
          />
        )}
        {criteria.education.level && (
           <CriteriaMatchItem
            label="Education"
            required={criteria.education.level.replace('_', ' ')}
            actual={resume.education ? resume.education.replace('_', ' ') : 'Not specified'}
            isMatched={resumeEduLevel >= criteriaEduLevel}
            weight={criteria.education.weight}
          />
        )}
        {criteria.keywords.items.length > 0 && (
          <CriteriaMatchList title="Keywords" items={keywordItems} weight={criteria.keywords.weight} />
        )}
      </div>
    </div>
  );
};

export default CriteriaMatch;
