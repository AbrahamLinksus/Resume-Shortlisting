
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { ResumeProvider } from '@/contexts/ResumeContext';
import Layout from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import UploadResume from '@/pages/UploadResume';
import CriteriaSelection from '@/pages/CriteriaSelection';
import RankedResults from '@/pages/RankedResults';
import ResumeDetails from '@/pages/ResumeDetails';

function App() {
  return (
    <ResumeProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/upload" element={<UploadResume />} />
          <Route path="/criteria" element={<CriteriaSelection />} />
          <Route path="/results" element={<RankedResults />} />
          <Route path="/resume/:id" element={<ResumeDetails />} />
        </Routes>
      </Layout>
      <Toaster />
    </ResumeProvider>
  );
}

export default App;
