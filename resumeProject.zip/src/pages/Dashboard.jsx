
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FileText, Upload, SlidersHorizontal, List, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useResumes } from '@/contexts/ResumeContext';

const Dashboard = () => {
  const { resumes, deleteResume } = useResumes();
  const [stats, setStats] = useState({
    totalResumes: 0,
    averageSkills: 0,
    averageExperience: 0
  });

  useEffect(() => {
    if (resumes.length > 0) {
      const totalSkills = resumes.reduce((sum, resume) => sum + resume.skills.length, 0);
      const totalExperience = resumes.reduce((sum, resume) => sum + resume.experience, 0);
      
      setStats({
        totalResumes: resumes.length,
        averageSkills: (totalSkills / resumes.length).toFixed(1),
        averageExperience: (totalExperience / resumes.length).toFixed(1)
      });
    }
  }, [resumes]);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-xl p-8 text-white shadow-xl"
      >
        <h1 className="text-3xl font-bold mb-4">Resume Shortlister Dashboard</h1>
        <p className="text-lg opacity-90 max-w-2xl">
          Upload resumes, set your criteria, and let our system rank candidates based on your requirements.
          Streamline your hiring process and find the best candidates faster.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div 
          variants={item}
          initial="hidden"
          animate="show"
          className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Total Resumes</h2>
            <div className="p-3 bg-blue-100 rounded-full">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <p className="text-3xl font-bold">{stats.totalResumes}</p>
        </motion.div>

        <motion.div 
          variants={item}
          initial="hidden"
          animate="show"
          transition={{ delay: 0.1 }}
          className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Avg. Skills</h2>
            <div className="p-3 bg-green-100 rounded-full">
              <SlidersHorizontal className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <p className="text-3xl font-bold">{stats.averageSkills}</p>
        </motion.div>

        <motion.div 
          variants={item}
          initial="hidden"
          animate="show"
          transition={{ delay: 0.2 }}
          className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Avg. Experience</h2>
            <div className="p-3 bg-purple-100 rounded-full">
              <List className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <p className="text-3xl font-bold">{stats.averageExperience} years</p>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
        >
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Link to="/upload">
              <Button className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700">
                <Upload className="w-4 h-4" />
                Upload Resumes
              </Button>
            </Link>
            <Link to="/criteria">
              <Button className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700">
                <SlidersHorizontal className="w-4 h-4" />
                Set Criteria
              </Button>
            </Link>
            <Link to="/results">
              <Button className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700">
                <List className="w-4 h-4" />
                View Results
              </Button>
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
        >
          <h2 className="text-xl font-semibold mb-4">Recent Resumes</h2>
          {resumes.length > 0 ? (
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {resumes.slice(0, 5).map((resume) => (
                <div 
                  key={resume.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-gray-500" />
                    <div>
                      <p className="font-medium">{resume.fileName}</p>
                      <p className="text-sm text-gray-500">
                        {new Date(resume.uploadDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteResume(resume.id)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No resumes uploaded yet</p>
              <Link to="/upload">
                <Button variant="link" className="mt-2">
                  Upload your first resume
                </Button>
              </Link>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
