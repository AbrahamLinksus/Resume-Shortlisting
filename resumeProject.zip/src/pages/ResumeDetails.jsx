
import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FileText } from 'lucide-react';
import { useResumes } from '@/contexts/ResumeContext';
import { useToast } from '@/components/ui/use-toast';
import ResumeHeader from '@/components/details/ResumeHeader';
import ResumeContent from '@/components/details/ResumeContent';
import ScoreCard from '@/components/details/ScoreCard';
import CriteriaMatch from '@/components/details/CriteriaMatch';
import ResumeInfoCard from '@/components/details/ResumeInfoCard';

const ResumeDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { resumes, deleteResume, calculateScore, criteria } = useResumes();
  const { toast } = useToast();
  const [resume, setResume] = useState(null);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const foundResume = resumes.find(r => r.id === id);

    if (foundResume) {
      setResume(foundResume);
      setScore(calculateScore(foundResume));
    } else {
      toast({
        title: 'Resume Not Found',
        description: 'The requested resume could not be found or may have been deleted.',
        variant: 'destructive',
      });
      navigate('/results', { replace: true });
    }
  }, [id, resumes, calculateScore, toast, navigate]);

  const handleDelete = useCallback(() => {
    if (resume) {
      deleteResume(resume.id);
      navigate('/results');
    }
  }, [deleteResume, navigate, resume]);

  if (!resume) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        <p className="ml-3 text-gray-600">Loading resume details...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <ResumeHeader onDelete={handleDelete} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <ResumeContent resume={resume} />

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="space-y-6"
        >
          <ScoreCard score={score} />
          <CriteriaMatch resume={resume} criteria={criteria} />
          <ResumeInfoCard resume={resume} />
        </motion.div>
      </div>
    </div>
  );
};

export default ResumeDetails;
