
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FileText, ArrowUpDown, ChevronRight, Award, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useResumes } from '@/contexts/ResumeContext';

const RankedResults = () => {
  const { rankedResumes, rankResumes } = useResumes();
  const [sortField, setSortField] = useState('score');
  const [sortDirection, setSortDirection] = useState('desc');
  const [filteredResumes, setFilteredResumes] = useState([]);
  const [minScore, setMinScore] = useState(0);

  useEffect(() => {
    if (rankedResumes.length === 0) {
      rankResumes();
    }
  }, []);

  useEffect(() => {
    const filtered = rankedResumes.filter(resume => resume.score >= minScore);
    
    const sorted = [...filtered].sort((a, b) => {
      let comparison = 0;
      
      if (sortField === 'score') {
        comparison = a.score - b.score;
      } else if (sortField === 'fileName') {
        comparison = a.fileName.localeCompare(b.fileName);
      } else if (sortField === 'uploadDate') {
        comparison = new Date(a.uploadDate) - new Date(b.uploadDate);
      } else if (sortField === 'experience') {
        comparison = a.experience - b.experience;
      }
      
      return sortDirection === 'desc' ? -comparison : comparison;
    });
    
    setFilteredResumes(sorted);
  }, [rankedResumes, sortField, sortDirection, minScore]);

  const toggleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const getSortIcon = (field) => {
    if (sortField !== field) return null;
    
    return (
      <ArrowUpDown className={`w-4 h-4 ml-1 ${
        sortDirection === 'asc' ? 'transform rotate-180' : ''
      }`} />
    );
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-blue-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-8 text-white shadow-xl"
      >
        <div className="flex items-center gap-3 mb-4">
          <Award className="w-8 h-8" />
          <h1 className="text-2xl font-bold">Ranked Results</h1>
        </div>
        <p className="opacity-90 max-w-2xl">
          Resumes have been ranked based on your selection criteria. Higher scores indicate better matches.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="bg-white rounded-xl p-6 shadow-md border border-gray-200"
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-500" />
            <h2 className="text-lg font-semibold">Filter Results</h2>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Minimum Score:</span>
              <select
                value={minScore}
                onChange={(e) => setMinScore(Number(e.target.value))}
                className="rounded-md border border-gray-300 p-1 text-sm"
              >
                <option value={0}>All</option>
                <option value={50}>50+</option>
                <option value={70}>70+</option>
                <option value={80}>80+</option>
                <option value={90}>90+</option>
              </select>
            </div>
            
            <Button
              onClick={() => rankResumes()}
              className="bg-blue-600 hover:bg-blue-700"
              size="sm"
            >
              Refresh Rankings
            </Button>
          </div>
        </div>
        
        {filteredResumes.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="p-3 text-left font-semibold text-gray-600">Rank</th>
                  <th 
                    className="p-3 text-left font-semibold text-gray-600 cursor-pointer"
                    onClick={() => toggleSort('fileName')}
                  >
                    <div className="flex items-center">
                      Resume {getSortIcon('fileName')}
                    </div>
                  </th>
                  <th 
                    className="p-3 text-left font-semibold text-gray-600 cursor-pointer"
                    onClick={() => toggleSort('score')}
                  >
                    <div className="flex items-center">
                      Match Score {getSortIcon('score')}
                    </div>
                  </th>
                  <th 
                    className="p-3 text-left font-semibold text-gray-600 cursor-pointer"
                    onClick={() => toggleSort('experience')}
                  >
                    <div className="flex items-center">
                      Experience {getSortIcon('experience')}
                    </div>
                  </th>
                  <th className="p-3 text-left font-semibold text-gray-600">Skills</th>
                  <th className="p-3 text-left font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredResumes.map((resume, index) => (
                  <motion.tr
                    key={resume.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-gray-200 hover:bg-gray-50"
                  >
                    <td className="p-3">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 text-gray-700 font-semibold">
                        {index + 1}
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-gray-500" />
                        <span className="font-medium">{resume.fileName}</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <Progress 
                          value={resume.score} 
                          className={`w-24 h-2 ${getScoreColor(resume.score)}`} 
                        />
                        <span className="font-semibold">{resume.score}%</span>
                      </div>
                    </td>
                    <td className="p-3">
                      {resume.experience} years
                    </td>
                    <td className="p-3">
                      <div className="flex flex-wrap gap-1 max-w-xs">
                        {resume.skills.slice(0, 3).map((skill, i) => (
                          <span 
                            key={i}
                            className="px-2 py-0.5 bg-blue-100 text-blue-800 text-xs rounded-full"
                          >
                            {skill}
                          </span>
                        ))}
                        {resume.skills.length > 3 && (
                          <span className="px-2 py-0.5 bg-gray-100 text-gray-800 text-xs rounded-full">
                            +{resume.skills.length - 3} more
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-3">
                      <Link to={`/resume/${resume.id}`}>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                        >
                          View Details
                          <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                      </Link>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-lg font-medium">No matching resumes found</p>
            <p className="text-sm mt-1">Try adjusting your filter criteria or upload more resumes</p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default RankedResults;
