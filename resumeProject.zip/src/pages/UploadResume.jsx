
import React, { useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useResumes } from '@/contexts/ResumeContext';
import FileDropArea from '@/components/upload/FileDropArea';
import FileList from '@/components/upload/FileList';
import ProcessingStatus from '@/components/upload/ProcessingStatus';
import { readFileAsText, isValidFileType } from '@/lib/fileUtils';

const UploadResume = () => {
  const [files, setFiles] = useState([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedCount, setProcessedCount] = useState(0);
  const fileInputRef = useRef(null);
  const { addResume, parseResumeText } = useResumes();
  const { toast } = useToast();
  const navigate = useNavigate();

  const showInvalidFileToast = useCallback(() => {
    toast({
      title: 'Invalid File Type',
      description: 'Please upload PDF, TXT, DOC or DOCX files only',
      variant: 'destructive',
    });
  }, [toast]);

  const addFiles = useCallback((newFiles) => {
    const validFiles = Array.from(newFiles).filter(isValidFileType);
    const invalidFilesCount = newFiles.length - validFiles.length;

    if (invalidFilesCount > 0) {
      showInvalidFileToast();
    }

    if (validFiles.length > 0) {
      setFiles(prev => [...prev, ...validFiles]);
    }
  }, [showInvalidFileToast]);

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
    addFiles(e.dataTransfer.files);
  }, [addFiles]);

  const handleFileChange = useCallback((e) => {
    addFiles(e.target.files);
    e.target.value = null;
  }, [addFiles]);

  const removeFile = useCallback((index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  }, []);

  const processFiles = useCallback(async () => {
    if (files.length === 0) {
      toast({
        title: 'No Files',
        description: 'Please upload at least one resume file',
        variant: 'destructive',
      });
      return;
    }

    setIsProcessing(true);
    setProcessedCount(0);
    let errorOccurred = false;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const text = await readFileAsText(file);
        const parsedData = parseResumeText(text);
        addResume(file, parsedData);
        setProcessedCount(prev => prev + 1);
      } catch (error) {
        console.error(`Error processing file ${file.name}:`, error);
        toast({
          title: 'Processing Error',
          description: `Failed to process ${file.name}. Please check the file format.`,
          variant: 'destructive',
        });
        errorOccurred = true;
      }
    }

    setIsProcessing(false);

    if (!errorOccurred) {
      toast({
        title: 'Processing Complete',
        description: `Successfully processed ${files.length} resume(s)`,
      });
      setFiles([]);
      navigate('/criteria');
    } else {
       toast({
        title: 'Processing Partially Completed',
        description: `Processed ${processedCount} out of ${files.length} resumes. Some files encountered errors.`,
        variant: 'destructive',
      });
    }
  }, [files, addResume, parseResumeText, toast, navigate, processedCount]);

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-xl p-8 shadow-md border border-gray-200"
      >
        <h1 className="text-2xl font-bold mb-6">Upload Resumes</h1>
        <FileDropArea
          isDragging={isDragging}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        />
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          multiple
          accept=".pdf,.txt,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        />
      </motion.div>

      <FileList files={files} onRemoveFile={removeFile} isProcessing={isProcessing} />

      {files.length > 0 && (
         <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: files.length > 0 ? 0.3 : 0 }}
          className="bg-white rounded-xl p-8 shadow-md border border-gray-200"
        >
          <ProcessingStatus
            isProcessing={isProcessing}
            processedCount={processedCount}
            totalFiles={files.length}
            onProcess={processFiles}
          />
        </motion.div>
      )}


      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: files.length > 0 ? 0.4 : 0.2 }}
        className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3"
      >
        <AlertCircle className="w-6 h-6 text-blue-500 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-blue-800">How it works</h3>
          <p className="text-blue-700 text-sm mt-1">
            Our system parses uploaded resumes to extract skills, experience, and education. This data helps rank candidates based on your criteria.
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default UploadResume;
