
import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { SlidersHorizontal, Save, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useResumes } from '@/contexts/ResumeContext';
import { SkillsCriteria, ExperienceCriteria, EducationCriteria, KeywordsCriteria } from '@/components/criteria/CriteriaSection';

const CriteriaSelection = () => {
  const { criteria, updateCriteria, rankResumes } = useResumes();
  const [localCriteria, setLocalCriteria] = useState({ ...criteria });
  const [newSkill, setNewSkill] = useState('');
  const [newKeyword, setNewKeyword] = useState('');
  const navigate = useNavigate();

  const handleWeightChange = useCallback((category, value) => {
    setLocalCriteria(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        weight: value[0]
      }
    }));
  }, []);

  const handleSave = useCallback(() => {
    updateCriteria(localCriteria);
  }, [updateCriteria, localCriteria]);

  const handleRankAndView = useCallback(() => {
    updateCriteria(localCriteria);
    rankResumes();
    navigate('/results');
  }, [updateCriteria, localCriteria, rankResumes, navigate]);

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-xl p-8 shadow-md border border-gray-200"
      >
        <div className="flex items-center gap-3 mb-6">
          <SlidersHorizontal className="w-6 h-6 text-blue-600" />
          <h1 className="text-2xl font-bold">Selection Criteria</h1>
        </div>

        <p className="text-gray-600 mb-8">
          Set your criteria to rank resumes. Adjust the importance (weight) of each factor using the sliders (0-10).
        </p>

        <div className="space-y-10">
          <SkillsCriteria
            criteria={localCriteria.skills}
            onWeightChange={handleWeightChange}
            localCriteria={localCriteria}
            setLocalCriteria={setLocalCriteria}
            newSkill={newSkill}
            setNewSkill={setNewSkill}
          />

          <ExperienceCriteria
            criteria={localCriteria.experience}
            onWeightChange={handleWeightChange}
            localCriteria={localCriteria}
            setLocalCriteria={setLocalCriteria}
          />

          <EducationCriteria
            criteria={localCriteria.education}
            onWeightChange={handleWeightChange}
            localCriteria={localCriteria}
            setLocalCriteria={setLocalCriteria}
          />

          <KeywordsCriteria
            criteria={localCriteria.keywords}
            onWeightChange={handleWeightChange}
            localCriteria={localCriteria}
            setLocalCriteria={setLocalCriteria}
            newKeyword={newKeyword}
            setNewKeyword={setNewKeyword}
          />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="flex flex-col sm:flex-row justify-between gap-4"
      >
        <Button
          onClick={handleSave}
          className="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 w-full sm:w-auto"
        >
          <Save className="w-4 h-4" />
          Save Criteria
        </Button>

        <Button
          onClick={handleRankAndView}
          className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 w-full sm:w-auto"
        >
          Rank Resumes & View Results
          <ArrowRight className="w-4 h-4" />
        </Button>
      </motion.div>
    </div>
  );
};

export default CriteriaSelection;
