
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { parseResumeText } from '@/lib/resumeParser';
import { calculateScore } from '@/lib/scoreCalculator';

const ResumeContext = createContext(null);

export const useResumes = () => {
  const context = useContext(ResumeContext);
  if (!context) {
    throw new Error('useResumes must be used within a ResumeProvider');
  }
  return context;
};

const defaultCriteria = {
  skills: { weight: 5, items: [] },
  experience: { weight: 3, years: 0 },
  education: { weight: 2, level: 'bachelor' },
  keywords: { weight: 4, items: [] }
};

export const ResumeProvider = ({ children }) => {
  const [resumes, setResumes] = useState([]);
  const [criteria, setCriteria] = useState(defaultCriteria);
  const [rankedResumes, setRankedResumes] = useState([]);
  const { toast } = useToast();

  const loadDataFromStorage = useCallback(() => {
    try {
      const savedResumes = localStorage.getItem('resumes');
      const savedCriteria = localStorage.getItem('criteria');

      if (savedResumes) {
        setResumes(JSON.parse(savedResumes));
      }
      if (savedCriteria) {
        setCriteria(JSON.parse(savedCriteria));
      } else {
        setCriteria(defaultCriteria);
      }
    } catch (error) {
      console.error('Error loading data from localStorage:', error);
      toast({
        title: 'Error',
        description: 'Failed to load saved data. Resetting to defaults.',
        variant: 'destructive',
      });
      localStorage.removeItem('resumes');
      localStorage.removeItem('criteria');
      setResumes([]);
      setCriteria(defaultCriteria);
    }
  }, [toast]);

  const saveDataToStorage = useCallback((key, data) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error(`Error saving ${key} to localStorage:`, error);
      toast({
        title: 'Storage Error',
        description: `Could not save ${key}. Changes might not persist.`,
        variant: 'destructive',
      });
    }
  }, [toast]);

  useEffect(() => {
    loadDataFromStorage();
  }, [loadDataFromStorage]);

  useEffect(() => {
    saveDataToStorage('resumes', resumes);
  }, [resumes, saveDataToStorage]);

  useEffect(() => {
    saveDataToStorage('criteria', criteria);
  }, [criteria, saveDataToStorage]);

  const addResume = useCallback((file, parsedData) => {
    const newResume = {
      id: Date.now().toString(),
      fileName: file.name,
      uploadDate: new Date().toISOString(),
      ...parsedData
    };

    setResumes(prev => {
      const updatedResumes = [...prev, newResume];
      return updatedResumes;
    });

    toast({
      title: 'Resume Added',
      description: `Successfully parsed and added ${file.name}`,
    });

    return newResume;
  }, [toast]);

  const deleteResume = useCallback((id) => {
    setResumes(prev => {
      const updatedResumes = prev.filter(resume => resume.id !== id);
      return updatedResumes;
    });
    setRankedResumes(prev => prev.filter(resume => resume.id !== id));

    toast({
      title: 'Resume Deleted',
      description: 'Resume has been removed from the system',
    });
  }, [toast]);

  const updateCriteria = useCallback((newCriteria) => {
    setCriteria(newCriteria);
    toast({
      title: 'Criteria Updated',
      description: 'Your selection criteria have been updated',
    });
  }, [toast]);

  const getScore = useCallback((resume) => {
    return calculateScore(resume, criteria);
  }, [criteria]);

  const rankResumes = useCallback(() => {
    if (resumes.length === 0) {
      setRankedResumes([]);
      return [];
    }
    
    const scored = resumes.map(resume => ({
      ...resume,
      score: getScore(resume)
    }));

    const ranked = [...scored].sort((a, b) => b.score - a.score);
    setRankedResumes(ranked);

    toast({
      title: 'Resumes Ranked',
      description: `Ranked ${ranked.length} resumes based on your criteria`,
    });

    return ranked;
  }, [resumes, getScore, toast]);

  const value = {
    resumes,
    criteria,
    rankedResumes,
    addResume,
    deleteResume,
    updateCriteria,
    parseResumeText,
    rankResumes,
    calculateScore: getScore
  };

  return (
    <ResumeContext.Provider value={value}>
      {children}
    </ResumeContext.Provider>
  );
};
